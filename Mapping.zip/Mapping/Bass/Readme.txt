Put any new icons and codes for them in here, so i can drag them out and add to game. 

Thanks
