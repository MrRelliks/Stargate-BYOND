Someone wanted me to write this shit down, so here goes.

# TODO List

1. DM Interpreter (WIP)
2. Map Parsing Framework
3. Networking
4. Garbage Collection
5. IDE (DreamMaker remake)
6. Authentication
7. Client
8. Map Rendering
9. Debugging/Profiling
10. Virtual Machine (WIP)
11. Savefiles
