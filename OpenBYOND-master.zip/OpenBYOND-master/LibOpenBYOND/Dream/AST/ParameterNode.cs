﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Irony.Ast;
using Irony.Interpreter.Ast;

namespace OpenBYOND.Dream.AST
{
    public class ParameterNode : Irony.Interpreter.Ast.AstNode
    {

    }
}
